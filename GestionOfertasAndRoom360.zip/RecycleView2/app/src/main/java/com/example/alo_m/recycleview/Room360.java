package com.example.alo_m.recycleview;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by ulise on 17/02/2018.
 */

public class Room360 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.Room_layout);
    }
}
